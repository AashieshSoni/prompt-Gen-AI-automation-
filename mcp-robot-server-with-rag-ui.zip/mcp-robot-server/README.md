# MCP Robot Server (Scaffold)
Minimal scaffold for an MCP-style Robot Framework server with:
- File browser (list, get)
- File save
- Run Robot tests and Python scripts
- Keyword generator & validator
- Robot parsing helpers
- Generators (Robot test, keyword, Selenium Python, REST API Robot)
- Simple RAG wrapper for Ollama (local LLM)

Run locally:
1. Create virtualenv: python -m venv .venv && . .venv/bin/activate
2. Install requirements: pip install -r requirements.txt
3. Start server: python -m app.main
4. Server runs on http://localhost:8000

Important security note: This scaffold executes code on the host. Use only in a trusted environment or container.


## New features added
- Structured RAG wrapper: app/rag/structured_prompt.py
- New endpoints: /rag/generate_structured and /rag/stream_structured (in app/main.py)
- React streaming RAG panel: react/src/components/RagStreamingPanel.jsx
