from jinja2 import Environment, FileSystemLoader
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
TEMPLATE_DIR = Path(__file__).parent / "templates"
env = Environment(loader=FileSystemLoader(str(TEMPLATE_DIR)))

def generate_robot_test_content(title: str, steps: list):
    tpl = env.get_template('robot_test.tpl')
    return tpl.render(title=title, steps=steps)

def generate_keyword_content(name: str, args: list, body: list):
    tpl = env.get_template('keyword.tpl')
    return tpl.render(name=name, args=args, body=body)

def generate_selenium_python(module_name: str, class_name: str, actions: list):
    tpl = env.get_template('selenium_py.tpl')
    return tpl.render(module_name=module_name, class_name=class_name, actions=actions)

def generate_rest_api_robot(test_name: str, path: str, method: str = 'GET'):
    tpl = env.get_template('rest_api_robot.tpl')
    return tpl.render(test_name=test_name, path=path, method=method)
