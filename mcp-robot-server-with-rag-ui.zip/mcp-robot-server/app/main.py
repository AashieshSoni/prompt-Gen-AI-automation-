from fastapi import FastAPI, Request
from fastapi.responses import StreamingResponse, JSONResponse
from pydantic import BaseModel
from typing import List, Optional
from app import mcp_tools
import uvicorn

# import structured prompt wrappers
from app.rag.structured_prompt import generate_structured, stream_structured

app = FastAPI(title="MCP Robot Server")

@app.get("/health")
def health():
    return {"status": "ok"}

# List robot tests
@app.get("/tools/list_robot_tests")
def list_robot_tests():
    return mcp_tools.list_robot_tests()

# Get test content
@app.get("/tools/get_test_case")
def get_test_case(path: str):
    return mcp_tools.get_test_case(path)

# List custom keywords
@app.get("/tools/list_custom_keywords")
def list_custom_keywords():
    return mcp_tools.list_custom_keywords()

# Generate new keyword file
class GenerateKeywordRequest(BaseModel):
    name: str
    body: str

@app.post("/tools/generate_keyword")
def generate_keyword(req: GenerateKeywordRequest):
    return mcp_tools.generate_keyword(req.name, req.body)

# Generate robot test
class GenerateRobotRequest(BaseModel):
    name: str
    body: str

@app.post("/tools/generate_robot_test")
def generate_robot_test(req: GenerateRobotRequest):
    return mcp_tools.generate_robot_test(req.name, req.body)

# Run robot test
@app.post("/tools/run_robot_test")
def run_robot_test(path: str):
    return mcp_tools.run_robot_test(path)

# Save arbitrary file (used by generators)
class SaveFileReq(BaseModel):
    path: str
    content: str

@app.post("/tools/save_file")
def save_file(req: SaveFileReq):
    return mcp_tools.save_file(req.path, req.content)

# Code execution endpoint (run Python safely) - limited
class RunPythonReq(BaseModel):
    path: str
    args: Optional[List[str]] = None

@app.post("/tools/run_python")
def run_python(req: RunPythonReq):
    return mcp_tools.run_python(req.path, req.args or [])

# Search project
@app.get("/tools/search_project")
def search_project(q: str):
    return mcp_tools.search_project(q)

# RAG structured generate endpoint (non-streaming)
class StructuredReq(BaseModel):
    prompt: str
    max_tokens: int = 800

@app.post('/rag/generate_structured')
def rag_generate_structured(req: StructuredReq):
    res = generate_structured(req.prompt, max_tokens=req.max_tokens)
    if res['parsed'] is None:
        return JSONResponse(status_code=502, content={"error": "failed to parse model JSON", "raw": res['raw']})
    return res['parsed']

# RAG streaming endpoint (raw stream of tokens)
@app.post('/rag/stream_structured')
def rag_stream_structured(req: StructuredReq):
    async def event_gen():
        for chunk in stream_structured(req.prompt, max_tokens=req.max_tokens):
            yield chunk
    return StreamingResponse(event_gen(), media_type='text/plain')

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
