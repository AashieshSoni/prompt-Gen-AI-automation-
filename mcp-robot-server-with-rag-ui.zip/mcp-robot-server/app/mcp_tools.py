import os
from pathlib import Path
import subprocess
from .storage import ensure_repo

ROOT = Path(__file__).resolve().parents[1]
ROBOT_BASE = ROOT / "robot"
ensure_repo(ROBOT_BASE)

def list_robot_tests():
    results = []
    for p in ROBOT_BASE.rglob("*.robot"):
        results.append(str(p.relative_to(ROOT)))
    return {"tests": results}

def get_test_case(path: str):
    p = ROOT / path
    if not p.exists():
        raise FileNotFoundError(str(p))
    return {"content": p.read_text(encoding='utf8')}

def list_custom_keywords():
    res = []
    for p in ROBOT_BASE.rglob("*keywords*.robot"):
        res.append(str(p.relative_to(ROOT)))
    for p in ROBOT_BASE.rglob("*.resource"):
        res.append(str(p.relative_to(ROOT)))
    return {"keyword_files": res}

def generate_keyword(name: str, body: str):
    dest = ROBOT_BASE / "custom_keywords"
    dest.mkdir(parents=True, exist_ok=True)
    path = dest / f"{name}.robot"
    path.write_text(body, encoding='utf8')
    return {"status": "created", "path": str(path.relative_to(ROOT))}

def generate_robot_test(name: str, body: str):
    dest = ROBOT_BASE / "tests"
    dest.mkdir(parents=True, exist_ok=True)
    path = dest / f"{name}.robot"
    path.write_text(body, encoding='utf8')
    return {"status": "created", "path": str(path.relative_to(ROOT))}

def run_robot_test(path: str):
    p = ROOT / path
    if not p.exists():
        return {"error": "file not found", "path": str(p)}
    result = subprocess.run(["robot", str(p)], capture_output=True, text=True)
    return {"stdout": result.stdout, "stderr": result.stderr, "rc": result.returncode}

def save_file(path: str, content: str):
    p = ROOT / path
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding='utf8')
    return {"status": "saved", "path": str(p.relative_to(ROOT))}

def run_python(path: str, args=None):
    p = ROOT / path
    if not p.exists():
        return {"error": "file not found", "path": str(p)}
    args = args or []
    result = subprocess.run(["python", str(p)] + args, capture_output=True, text=True)
    return {"stdout": result.stdout, "stderr": result.stderr, "rc": result.returncode}

def search_project(q: str):
    matches = []
    for p in ROBOT_BASE.rglob("*.robot"):
        text = p.read_text(encoding='utf8')
        if q.lower() in text.lower():
            matches.append(str(p.relative_to(ROOT)))
    return {"matches": matches}
