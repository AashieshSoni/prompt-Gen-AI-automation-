import os
import requests
from typing import List
OLLAMA_URL = os.getenv('OLLAMA_URL','http://localhost:11434')
MODEL = os.getenv('OLLAMA_MODEL','llama2')

def rag_generate(prompt: str, top_k:int=5):
    from pathlib import Path
    ROOT = Path(__file__).resolve().parents[1]
    project = ROOT / 'robot'
    candidates = []
    for p in project.rglob('*.robot'):
        text = p.read_text(encoding='utf8')
        if any(tok.lower() in text.lower() for tok in prompt.split()[:5]):
            candidates.append({'path': str(p.relative_to(ROOT)), 'text': text[:200]})
    system_prompt = "You are a helpful assistant that uses project context to generate Robot Framework tests."
    augmented_prompt = system_prompt + "\n\nContext snippets:\n"
    for c in candidates[:top_k]:
        augmented_prompt += f"File: {c['path']}\n{c['text']}\n---\n"
    augmented_prompt += "\nUser prompt:\n" + prompt
    try:
        r = requests.post(f"{OLLAMA_URL}/complete", json={
            "model": MODEL,
            "prompt": augmented_prompt,
            "max_tokens": 800
        })
        r.raise_for_status()
        return {"generated": r.json()}
    except Exception as e:
        return {"error": str(e), "candidates": candidates}
