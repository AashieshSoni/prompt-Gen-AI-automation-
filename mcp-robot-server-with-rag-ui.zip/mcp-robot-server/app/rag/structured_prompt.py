# app/rag/structured_prompt.py
import os
import re
import json
import httpx
from typing import AsyncIterator, Optional

OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434")
MODEL = os.getenv("OLLAMA_MODEL", "llama3")

SYSTEM_INSTRUCTION = '''You are an expert test automation assistant.\n\nREQUIREMENTS:\n- ALWAYS return valid JSON object only (no other text) with the keys: "robot", "keyword", "playwright", "api".\n- Each value should be a string. If you have nothing to return for a key, return an empty string.\n- Wrap code blocks in triple backticks is allowed inside the string values, but the top-level HTTP response must be parseable as JSON.\n- Use concise, production-ready Robot Framework syntax and working Playwright Python snippets where possible.\n- If returning multiple files or multiple tests, concatenate them into the single string value separated by '---' markers.\n- Include a metadata key `metadata` with {"generated_by":"ollama", "model":"%s"}.\n''' % MODEL

# Helper: build the full prompt
def build_prompt(user_prompt: str) -> str:
    return SYSTEM_INSTRUCTION + "\nUSER PROMPT:\n" + user_prompt

# Helper: extract json object from raw text robustly
def extract_json_from_text(text: str) -> Optional[dict]:
    # Try direct parse first
    try:
        return json.loads(text)
    except Exception:
        pass
    # Try to find first JSON object braces
    m = re.search(r"\{.*\}", text, flags=re.DOTALL)
    if m:
        candidate = m.group(0)
        try:
            return json.loads(candidate)
        except Exception:
            pass
    # Try to remove markdown fences and parse
    cleaned = re.sub(r"```[\s\S]*?```", lambda m: m.group(0).replace('```', ''), text)
    try:
        return json.loads(cleaned)
    except Exception:
        return None

# Non-streaming call
def call_ollama_sync(prompt: str, max_tokens: int = 800):
    # Adjust endpoint path depending on Ollama version. Common endpoints: /api/generate or /complete
    url = os.getenv("OLLAMA_API_PATH", None) or f"{OLLAMA_URL}/api/generate"
    payload = {"model": MODEL, "prompt": prompt, "max_tokens": max_tokens, "stream": False}
    with httpx.Client(timeout=60) as c:
        r = c.post(url, json=payload)
        r.raise_for_status()
        j = r.json()
        # Prefer fields commonly returned
        if isinstance(j, dict):
            text = j.get('response') or j.get('text') or ''
            if not text and 'choices' in j and isinstance(j['choices'], list) and j['choices']:
                text = j['choices'][0].get('text','')
        else:
            text = str(j)
    parsed = extract_json_from_text(text)
    return parsed, text

# Streaming proxy (yields raw chunks from Ollama streaming endpoint)
def stream_ollama(prompt: str, max_tokens: int = 800):
    url = os.getenv("OLLAMA_API_PATH", None) or f"{OLLAMA_URL}/api/generate"
    payload = {"model": MODEL, "prompt": prompt, "max_tokens": max_tokens, "stream": True}
    with httpx.stream("POST", url, json=payload, timeout=None) as r:
        r.raise_for_status()
        # Some Ollama versions stream text lines; iterate bytes
        for chunk in r.iter_text():
            if chunk:
                yield chunk

# Async wrappers for FastAPI
def generate_structured(user_prompt: str, max_tokens: int = 800):
    prompt = build_prompt(user_prompt)
    parsed, raw = call_ollama_sync(prompt, max_tokens=max_tokens)
    return {"parsed": parsed, "raw": raw}

def stream_structured(user_prompt: str, max_tokens: int = 800):
    prompt = build_prompt(user_prompt)
    for chunk in stream_ollama(prompt, max_tokens=max_tokens):
        yield chunk
