from robot.api import TestSuiteBuilder

def parse_robot_suite(path: str):
    suite = TestSuiteBuilder().build(str(path))
    data = {"suite_name": suite.name, "tests": [], "keywords": []}
    for t in suite.tests:
        data["tests"].append(t.name)
    for k in suite.keywords:
        data["keywords"].append(k.name)
    return data

def validate_keyword_file(path: str):
    text = open(path, encoding='utf8').read()
    if '*** Keywords ***' not in text:
        return {"ok": False, "reason": "missing Keywords section"}
    return {"ok": True}
