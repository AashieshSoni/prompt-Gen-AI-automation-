from pathlib import Path
def ensure_repo(base: Path):
    base.mkdir(parents=True, exist_ok=True)
    (base / 'tests').mkdir(parents=True, exist_ok=True)
    (base / 'resources').mkdir(parents=True, exist_ok=True)
    (base / 'custom_keywords').mkdir(parents=True, exist_ok=True)
