import React, { useState, useRef } from 'react';

const BASE = process.env.REACT_APP_API_BASE || 'http://localhost:8000';

export default function RagStreamingPanel() {
  const [prompt, setPrompt] = useState('Create a Robot Framework login test using Login Using Credentials');
  const [streaming, setStreaming] = useState(false);
  const [output, setOutput] = useState('');
  const [parsed, setParsed] = useState(null);
  const controllerRef = useRef(null);

  const startStream = async () => {
    setStreaming(true);
    setOutput('');
    setParsed(null);
    const res = await fetch(`${BASE}/rag/stream_structured`, {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ prompt, max_tokens: 800 })
    });
    if (!res.body) {
      const text = await res.text();
      setOutput(text);
      setStreaming(false);
      return;
    }
    const reader = res.body.getReader();
    const decoder = new TextDecoder();

    async function read() {
      try {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          const chunk = decoder.decode(value, { stream: true });
          setOutput(prev => prev + chunk);
        }
      } catch (e) {
        console.error(e);
      } finally {
        setStreaming(false);
      }
    }

    read();
  };

  const stopAndParse = async () => {
    try {
      const start = output.indexOf('{');
      const end = output.lastIndexOf('}');
      if (start !== -1 && end !== -1) {
        const candidate = output.substring(start, end+1);
        const j = JSON.parse(candidate);
        setParsed(j);
      } else {
        setParsed(JSON.parse(output));
      }
    } catch (e) {
      alert('Failed to parse JSON from model output. Check raw output.');
      console.error('parse error', e);
    }
  };

  const saveAndRun = async (run=false) => {
    const resp = await fetch(`${BASE}/tools/generate_and_save`, {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ prompt, base_name: 'ui_generated', top_k: 5 })
    });
    const j = await resp.json();
    alert('Saved: ' + JSON.stringify(j.files || j));
    if (run) {
      const robotPath = j.files && j.files.robot_test;
      if (robotPath) {
        const runRes = await fetch(`${BASE}/tools/run_robot_test`, {
          method: 'POST',
          headers: {'Content-Type':'application/json'},
          body: JSON.stringify({ path: robotPath })
        });
        const rr = await runRes.json();
        alert('Run completed. RC=' + rr.get('rc'));
      } else alert('No robot_test path returned');
    }
  };

  return (
    <div className="p-4">
      <h3 className="font-bold mb-2">RAG Streaming Panel</h3>
      <textarea value={prompt} onChange={e=>setPrompt(e.target.value)} className="w-full h-24 p-2 border"/>
      <div className="mt-2 flex gap-2">
        <button onClick={startStream} disabled={streaming} className="px-3 py-1 bg-blue-600 text-white rounded">Stream</button>
        <button onClick={stopAndParse} disabled={streaming} className="px-3 py-1 bg-green-600 text-white rounded">Parse</button>
        <button onClick={()=>saveAndRun(false)} className="px-3 py-1 bg-slate-600 text-white rounded">Save</button>
        <button onClick={()=>saveAndRun(true)} className="px-3 py-1 bg-rose-600 text-white rounded">Save & Run</button>
      </div>

      <div className="mt-4">
        <h4 className="font-semibold">Stream Output</h4>
        <pre className="whitespace-pre-wrap p-2 border h-64 overflow-auto bg-black text-white">{output}</pre>
      </div>

      {parsed && (
        <div className="mt-4">
          <h4 className="font-semibold">Parsed JSON</h4>
          <pre className="p-2 border h-64 overflow-auto">{JSON.stringify(parsed, null, 2)}</pre>
        </div>
      )}
    </div>
  );
}
